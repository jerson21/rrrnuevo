// fabricacion.js 
